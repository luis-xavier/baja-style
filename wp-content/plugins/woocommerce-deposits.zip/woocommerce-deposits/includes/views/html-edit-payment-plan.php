<div class="wrap woocommerce wc-deposits-admin">
	<h2><?php _e( 'Edit Payment Plan', 'woocommerce-deposits' ); ?></h2>
	<?php include( 'html-payment-plan-form.php' ); ?>
</div>